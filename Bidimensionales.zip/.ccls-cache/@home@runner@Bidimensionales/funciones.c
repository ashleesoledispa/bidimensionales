#include "funciones.h"
#include "lecturas.h"
#include <stdio.h>
// meses se define en todos los apartados sino no es valido
#define MESES 12

int menu() {
  printf("1.- Ingresar indices de lluvia\n");
  printf("2.- Mostrar promedios\n");
  printf("3.- Salir\n");
  return leerEnteroEntre("Ingrese una opcion: ", 1, 3);
}
// Matriz de columna nunca puede quedar vacía [MESES]
void ingresarDatos(float datos[][MESES], int filas, int columnas) {
  for (int i = 0; i < filas; i++) {
    for (int j = 0; j < columnas; j++) {
      printf("Ingrese la lluvia del anio %d en el mes %d\n", i + 1, j + 1);
      datos[i][j] = leerFlotante("Ingrese el valor");
      // Programa sin lecturas
      // scanf("%f", &datos[i][j]);
    }
  }
}

void mostrarDatos(const float datos[][MESES], int filas, int columnas) {
  for (int i = 0; i < filas; i++) {
    for (int j = 0; j < columnas; j++) {
      printf("%8.2f", datos[i][j]);
    }
    printf("\n");
  }
}

void calcularLluviaAnual(const float datos[][MESES], int filas, int columnas) {
  float suma = 0;
  float promedio;

  for (int i = 0; i < filas; i++) {
    float sumaAnual = 0;
    for (int j = 0; j < columnas;
         j++) { // Se ingresa la suma en el segundo for porque este es el que
                // permite moverse
      sumaAnual += datos[i][j];
    }
    suma += sumaAnual;

    printf("La cantidad de lluvia en el año %d es %.2f\n", i + 1, sumaAnual);
    printf("\n");
  }

  promedio = suma / filas;

  printf("El promedio de lluvia es %.2f\n", promedio);
}
void calcularLluviaMensual(const float datos[][MESES], int filas, int columnas) {
  float static sumaMensual[MESES]; //se pone el static para que me rellene de 0
  float promedio;

  for (int j = 0; j < columnas; j++) {
    for (int i = 0; i < filas; i++) {
      sumaMensual[j] += datos[i][j];
    }
  }

  printf("Promedio de lluvia mensual:\n");
  for (int j = 0; j < columnas; j++) {
    promedio = sumaMensual[j] / filas;
    printf("Mes %d: %.2f\n", j + 1, promedio);
  }
}