#define MESES 12

int menu();
void ingresarDatos(float[][MESES], int, int);
void mostrarDatos(const float[][MESES], int, int);
void calcularLluviaAnual(const float[][MESES], int, int);
void calcularLluviaMensual(const float[][MESES], int, int);
