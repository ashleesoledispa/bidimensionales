#include "funciones.h"
#include <stdio.h>

#define ANIO 2
#define MESES 12

int main(void) {
  float lluvias[ANIO][MESES];
  int opc;
  do {
    opc = menu();
    switch (opc) {
    case 1: {
      ingresarDatos(lluvias, ANIO, MESES);
      mostrarDatos(lluvias, ANIO, MESES);
    } break;
    case 2: {
      mostrarDatos(lluvias, ANIO, MESES);
      calcularLluviaAnual(lluvias, ANIO, MESES);
      calcularLluviaMensual(lluvias, ANIO, MESES);
      return 0;
    }
    }
  } while (opc != 3);

  return 0;
}